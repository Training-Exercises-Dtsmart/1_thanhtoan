<?php
/**
 * encoding_utf-8.php
 *
 * @package default
 */


?>
äüöß
