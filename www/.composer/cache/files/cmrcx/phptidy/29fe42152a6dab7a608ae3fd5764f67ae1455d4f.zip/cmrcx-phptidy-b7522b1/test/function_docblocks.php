<?


function x() {}

// another function
function y() {
}

# comment1
# comment2
function z() {}

/** comment3 */
function a() {}

/* comment4 */
function b() {}

// comment5
function c() {}

function d($a, array $b, MyClass $c, &$d=0, array &$e=array(), MyClass &$f, & $g = 0, array & $h = array(), MyLongClass & $i) {}

/**
 * @param mixed $a
 * @param $b comment
 * @param object $c comment
 * @param mixed $d
 * @param $e
 * @param mixed $f comment
 */
function e($a___, array $b, MyClass $c, &$d=0, array &$e=array(), MyClass &$f, & $g_ = 0, array & $h = array(), MyLongClass & $i) {}


