<?php
/**
 * indent_elseif.php
 *
 * @package default
 * @see include.php
 */


if ($x==1) {
	//
} elseif ($y==2) {
	//
} else if ($z==3) {
	//
} else {
	//
}
