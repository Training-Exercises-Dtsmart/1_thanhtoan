<?php

$keep_open_echo_tags=true;