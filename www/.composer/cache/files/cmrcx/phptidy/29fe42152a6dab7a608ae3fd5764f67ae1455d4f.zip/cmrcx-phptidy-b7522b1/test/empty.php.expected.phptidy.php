<?php
/**
 * empty.php
 *
 * @package default
 */
