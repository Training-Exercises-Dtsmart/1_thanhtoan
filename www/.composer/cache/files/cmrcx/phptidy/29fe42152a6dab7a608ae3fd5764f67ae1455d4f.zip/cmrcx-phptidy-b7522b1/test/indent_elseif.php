<?

if ($x==1) {
//
} elseif ($y==2) {
//
} else if ($z==3) {
//
} else {
//
}
