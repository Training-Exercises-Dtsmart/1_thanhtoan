<?php
return [
    1000 => [
        'Editor',
    ],
];
