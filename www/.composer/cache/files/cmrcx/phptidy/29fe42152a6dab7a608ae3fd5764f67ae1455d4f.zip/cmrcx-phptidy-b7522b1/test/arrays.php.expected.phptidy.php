<?php
/**
 * arrays.php
 *
 * @package default
 */


$x = array(
	1=>"Hello",
	"abc" => 333);

$y = array(1, 2, 3,   4, "Hello");

$x = [
	1=>"Hello",
	"abc" => 333];

$y = [1, 2, 3,   4, "Hello"];
