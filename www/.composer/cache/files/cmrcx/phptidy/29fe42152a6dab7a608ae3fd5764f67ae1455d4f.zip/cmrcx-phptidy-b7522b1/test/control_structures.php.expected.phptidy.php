<?php
/**
 * control_structures.php
 *
 * @package default
 */


switch ($x) {
case 1:
	break;
case 2:


	continue;

case 10:
	echo "Hello";
default:
	exit();

}
