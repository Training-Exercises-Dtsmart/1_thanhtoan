<?php
/**
 * anonymous_functions.php
 *
 * @package default
 */


$x = function() {};

$x = function () {};

// comment
echo function() {
	return "Hello";
};

// shell comment line 1
// shell comment line 2
$z = strlen( function() { return 1; } );
