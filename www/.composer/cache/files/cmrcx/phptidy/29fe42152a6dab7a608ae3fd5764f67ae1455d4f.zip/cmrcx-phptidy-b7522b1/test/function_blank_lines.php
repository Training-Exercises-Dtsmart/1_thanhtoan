<?

$y=1;
/**
 * function
 */
function x() {}
$x=3;
