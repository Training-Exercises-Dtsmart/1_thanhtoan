Web UI
------

> Note! The Web UI is not as actively supported as CLI usage, and using a custom `batch` command is recommended.

As an alternative or for debugging, you can visit your application's *Gii*-module (eg. `index.php?r=gii`) and choose 
one of the generators from the main menu screen.

For basic usage instructions see the [Yii2 Guide section for Gii](http://www.yiiframework.com/doc-2.0/guide-tool-gii.html).

