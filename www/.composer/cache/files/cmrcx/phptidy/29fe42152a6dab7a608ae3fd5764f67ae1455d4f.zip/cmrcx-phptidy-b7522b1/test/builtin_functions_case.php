<?

echo Link('target', 'link');

echo $this->Link('target', 'link');

echo ownFunction();

function ownFunction() {}
