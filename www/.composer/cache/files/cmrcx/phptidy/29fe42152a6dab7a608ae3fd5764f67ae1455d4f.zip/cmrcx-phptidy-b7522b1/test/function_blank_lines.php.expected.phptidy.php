<?php
/**
 * function_blank_lines.php
 *
 * @package default
 * @see include.php
 */


$y=1;


/**
 * function
 */
function x() {}


$x=3;
