<?php
# TODO: remove absolute path
new yii\web\Application(require ('/app/src/config/main.php'));
