<?php
/**
 * indent_curly_brace_open.php
 *
 * @package default
 */


if (false)
	return;


/**
 *
 */
function x() {

	if (true) {
	}


	/**
	 *
	 */
	function &xxx() {
	}


	{
		exit;
	}


	{}


}
