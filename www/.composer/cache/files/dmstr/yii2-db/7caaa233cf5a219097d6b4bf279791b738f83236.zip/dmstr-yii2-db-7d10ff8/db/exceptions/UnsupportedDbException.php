<?php

namespace dmstr\db\exceptions;

/**
 * Class UnsupportedDbException
 * @package dmstr\db\exceptions
 * @author Alexandr Aboimov <akasstalkalex@gmail.com>
 */
class UnsupportedDbException extends \Exception
{

}