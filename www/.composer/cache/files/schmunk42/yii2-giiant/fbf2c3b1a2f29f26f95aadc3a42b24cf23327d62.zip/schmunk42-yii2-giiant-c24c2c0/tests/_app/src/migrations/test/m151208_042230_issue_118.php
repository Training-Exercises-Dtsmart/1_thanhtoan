<?php

use yii\db\Schema;
use yii\db\Migration;

class m151208_042230_issue_118 extends \dmstr\db\mysql\FileMigration
{
    public $file = '118-tagai.sql';
}
