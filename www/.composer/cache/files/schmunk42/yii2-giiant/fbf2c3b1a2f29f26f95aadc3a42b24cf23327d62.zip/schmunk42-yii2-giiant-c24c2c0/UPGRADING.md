0.4 to 0.5
----------

Several namespace changes were made in 0.5, you need to adjust your source-code

- `giiant\crud\callbacks` -> `giiant\generators\crud\callbacks`
- `schmunk42\giiant\crud\Generator` -> `schmunk42\giiant\generators\crud\Generator`
