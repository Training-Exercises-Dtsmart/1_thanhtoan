<?

// comment
if ($example) {

	// comment
	if ( ob_get_contents() ) ob_end_flush();

	if (php_sapi_name()!="cli") {
		// comment
	}

}
