<?

if (false)
return;

function x() {

if (true) {
}

function &xxx() {
}

{
exit;
}

{}

}
