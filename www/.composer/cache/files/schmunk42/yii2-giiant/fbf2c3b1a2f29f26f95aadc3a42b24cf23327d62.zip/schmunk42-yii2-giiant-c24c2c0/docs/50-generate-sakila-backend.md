Tutorial: Sakila backend CRUDs
==============================

> WIP: See `tests/`...
