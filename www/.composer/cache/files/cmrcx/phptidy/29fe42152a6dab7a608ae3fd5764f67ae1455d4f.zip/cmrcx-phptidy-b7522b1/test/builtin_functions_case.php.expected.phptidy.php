<?php
/**
 * builtin_functions_case.php
 *
 * @package default
 */


echo link('target', 'link');

echo $this->Link('target', 'link');

echo ownFunction();


/**
 *
 */
function ownFunction() {}
