<?

function example() {
	return(true);
	return  true;
	return true ;
	return(true);
	return (true);
	return(true) ;
	return ((true));
	return intval(1);
	return (is_integer(1)) ? 'yes' : array();
	return (intval(1) + intval(1));
	return intval(1) + intval(1);
	return (intval(intval(1) + intval(1)));
	return(intval(intval(1) + intval(1))) ;
	return (
		is_integer($x) and
		is_integer($y)
	);
	return(
		is_integer($x) and
		is_integer($y)
	);
	return;
	return ;
}
