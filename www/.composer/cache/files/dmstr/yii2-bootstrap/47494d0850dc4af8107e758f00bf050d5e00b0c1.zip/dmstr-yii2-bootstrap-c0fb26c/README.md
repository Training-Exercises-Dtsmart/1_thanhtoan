yii2-bootstrap
==============
yii2 bootstrap components and extensions from diemeisterei GmbH

Installation
------------

The preferred way to install this extension is through [composer](http://getcomposer.org/download/).

Either run

```
php composer.phar require --prefer-dist dmstr/yii2-bootstrap "*"
```

or add

```
"dmstr/yii2-bootstrap": "*"
```

to the require section of your `composer.json` file.


Usage
-----

TBD.
