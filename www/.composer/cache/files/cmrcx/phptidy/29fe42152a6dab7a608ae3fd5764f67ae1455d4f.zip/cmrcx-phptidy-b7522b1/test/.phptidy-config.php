<?php
$project_files = array("*.php");
$docrootvars = array('DOCROOT', '$docroot');
$encoding = "UTF-8";
