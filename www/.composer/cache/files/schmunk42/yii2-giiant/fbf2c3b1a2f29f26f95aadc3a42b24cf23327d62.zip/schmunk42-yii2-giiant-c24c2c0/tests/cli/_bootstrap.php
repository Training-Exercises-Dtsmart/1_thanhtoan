<?php
#$config = require(dirname(__DIR__) . '/_config/cli.php');
#$_app = new yii\console\Application($config);

#\Yii::setAlias('testmodels', '@tests/models');